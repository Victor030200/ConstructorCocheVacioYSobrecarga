/**
 * Esta Clase Nos Ejemplifica El Uso De Un Constructor Vacio & Sobrecargado.
 *
 * @author: Victor Rodríguez Rodríguez 5IM6
 * @version: 02/09/2017
 */
package ejemplocochevaciosobrecargado;

/**
 * Clase Ejemplo Coche, Con Constructor Vacío & Sobrecargado
 *
 */
public class ConstructorCoche {

    /**
     * Declaración De Las Variables Privadas String Para El Constructor Vacio
     *
     */
    private String Gasolina;
    private String Llaves;
    private String Conductor;
    private String Bateria;

    /**
     * Declaración De Las Variables Privadas String Para El Constructor
     * Sobrecargadp
     *
     */
    String LaGasolina;
    String LasLlaves;
    String ElConductor;
    String LaBateria;

    /**
     * Publico
     *
     */
    public ConstructorCoche() {

    }

    /**
     * Declaración De Las Variables Privadas String, Del Constructor A Uno Nuevo
     *
     */
    public ConstructorCoche(String LaGasolina, String LasLlaves, String ElConductor, String LaBateria) {

        this.LaGasolina = LaGasolina;
        this.LasLlaves = LasLlaves;
        this.ElConductor = ElConductor;
        this.LaBateria = LaBateria;
    }
    //Cierre Del Método
}
//Cierre De La Clase
