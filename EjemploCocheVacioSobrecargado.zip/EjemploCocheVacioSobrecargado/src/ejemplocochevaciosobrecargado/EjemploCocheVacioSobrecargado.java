/**
 * Esta Clase Nos Ejemplifica El Uso De Un Constructor Vacio & Sobrecargado.
 *
 * @author: Victor Rodríguez Rodríguez 5IM6
 * @version: 02/09/2017
 */
package ejemplocochevaciosobrecargado;

/**
 * Clase Ejemplo Coche, Con Constructor Vacio & Sobrecargado
 *
 */
public class EjemploCocheVacioSobrecargado {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        /**
         * Se Declara El Constructor En La Clase ConstructorCoche, Se Crea El
         * Objeto "MiConstructor" Y Se Indica Que Esta Vacío Al Mismo Tiempo Se
         * Declara El Constructor En La Clase ConstructorCoche, Se Crea El
         * Objeto "Objeto" Y Se Indica Que Esta Siendo Sobrecargado.
         */
        ConstructorCoche miConstructor = new ConstructorCoche();
        ConstructorCoche Objeto = new ConstructorCoche("NecesitaGasolina", "RequiereLasLlaves", "LoUtilizaUnConductor", "UsaLaBateria");
    }
//Cierre Del Metodo
}
//Cierre De La Clase
